<?php include("PagSeguroLibrary.php"); ?>
<html>
<head>
</head>
<body>
<h3>Integra��o Funcionando</h3>

<?php

// Cria o objeto Pagsegguro de pagamento
$paymentRequest = new PagSeguroPaymentRequest();  
$paymentRequest->addItem('0001', 'Notebook', 1, 2430.00);  
$paymentRequest->addItem('0002', 'Mochila',  1, 150.99);  

// Dados do comprador
$paymentRequest->setSender(  
    'Jos� Comprador',   
    'comprador@uol.com.br',   
    '11',   
    '56273440'  
);  

// Dados do endere�o do comprador
$paymentRequest->setShippingAddress(  
    '01452002',   
    'Av. Brig. Faria Lima',       
    '1384',       
    'apto. 114',       
    'Jardim Paulistano',      
    'S�o Paulo',      
    'SP',     
    'BRA'     
);  

// Moeda corrente - BRL
$paymentRequest->setCurrency("BRL");  

// Tipo de Frete
// 1	 PAC	 Encomenda normal
// 2	 SEDEX	 SEDEX dos Correios
// 3	 NOT_SPECIFIED	 N�o especificar tipo de frete
$paymentRequest->setShippingType(3);

// C�digo de refer�ncia
$paymentRequest->setReference("I9635");

// Outros paramentros
$paymentRequest->addParameter('notificationURL', 'http://www.meusite.com.br/notificacao');  
$paymentRequest->addParameter('senderCPF', '12345678901');  

// Informando as credenciais  
$credentials = new PagSeguroAccountCredentials(  
    'wmacibnc@hotmail.com',   
    'B36F042789B840719CB7FD53B1F7A4D2'  
);  

// fazendo a requisi��o a API do PagSeguro pra obter a URL de pagamento  
$url = $paymentRequest->register($credentials);

echo $url;


/* Definindo a data de �nicio da consulta */  
$initialDate = '2011-06-01T08:50';  
  
/* Definindo a data de t�rmino da consulta */  
$finalDate   = '2013-10-09T10:30';  
  
/* Definindo o n�mero m�ximo de resultados por p�gina */  
$maxPageResults = 20;  
  
/* Definindo o n�mero da p�gina */  
$pageNumber = 1;  
  
/* Realizando a consulta */  
$result = PagSeguroTransactionSearchService::searchByDate(  
    $credentials,       // credenciais  
    $pageNumber,        // n�mero da p�gina  
    $maxPageResults,    // n�mero m�ximo de resultados por p�gina  
    $initialDate,       // data de �nicio  
    $finalDate         // data de t�rmino  
);  
  
/* Obtendo as transa��es do objeto PagSeguroTransactionSearchResult */  
$transactions = $result->getTransactions();  

echo $transactions;








 ?>
</body>
</html>
